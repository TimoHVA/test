
def safe_div(a, b):
    if b == 0:
        return 0
    return a / b